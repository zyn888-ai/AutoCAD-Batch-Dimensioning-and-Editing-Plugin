@echo off
setlocal
cd /d "%~dp0"
title SmartRoad Command Registration Repair

echo SmartRoad CAD Dimension Tools v1.3.1
echo This repairs all ZHDIM demand-load command mappings.
echo Close all AutoCAD windows before continuing.
echo Administrator approval will be requested.
echo.

if not exist "%~dp0Repair-CommandRegistration.ps1" (
    echo REPAIR FAILED: Repair-CommandRegistration.ps1 is missing.
    echo Please extract the complete ZIP package first.
    pause
    exit /b 2
)

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-CommandRegistration.ps1"
set "RESULT=%ERRORLEVEL%"

echo.
if not "%RESULT%"=="0" (
    echo REPAIR FAILED. Run the full installer first, then open Repair-Result.txt.
) else (
    echo REPAIR AND VERIFICATION SUCCEEDED.
    echo Restart AutoCAD, then run ZHDIMHELP.
)
echo.
pause
exit /b %RESULT%
