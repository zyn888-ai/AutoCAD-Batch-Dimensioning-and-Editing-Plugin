@echo off
setlocal
cd /d "%~dp0"
title SmartRoad AutoCAD Version Check

echo This check reads the Autodesk registry only.
echo It does not install or modify files.
echo.

if not exist "%~dp0Install-SmartRoad.ps1" (
    echo CHECK FAILED: Install-SmartRoad.ps1 is missing.
    echo Please extract the complete ZIP package first.
    pause
    exit /b 2
)

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SmartRoad.ps1" -ProbeOnly
set "RESULT=%ERRORLEVEL%"

echo.
if not "%RESULT%"=="0" (
    echo No supported AutoCAD installation was detected, or the check failed.
    echo See Install-Result.txt when present.
) else (
    echo Detection completed successfully.
)
echo.
pause
exit /b %RESULT%
