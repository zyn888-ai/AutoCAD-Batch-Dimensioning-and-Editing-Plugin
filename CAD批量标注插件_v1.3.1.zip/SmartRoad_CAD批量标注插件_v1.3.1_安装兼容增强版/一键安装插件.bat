@echo off
setlocal
cd /d "%~dp0"
title SmartRoad CAD Dimension Tools Installer

echo SmartRoad CAD Dimension Tools v1.3.1
echo AutoCAD 2019-2022 x64 installer compatibility build.
echo Close all AutoCAD windows before continuing.
echo Administrator approval will be requested.
echo.

if not exist "%~dp0Install-SmartRoad.ps1" (
    echo INSTALLATION FAILED: Install-SmartRoad.ps1 is missing.
    echo Please extract the complete ZIP package before running this file.
    pause
    exit /b 2
)

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SmartRoad.ps1"
set "RESULT=%ERRORLEVEL%"

echo.
if not "%RESULT%"=="0" (
    echo INSTALLATION FAILED.
    echo Open Install-Result.txt in this folder and send the complete file to the developer.
) else (
    echo INSTALLATION AND VERIFICATION SUCCEEDED.
    echo Restart AutoCAD, then run ZHDIMHELP.
)
echo.
pause
exit /b %RESULT%
